KEAN Platform - ZIP

Quick start (Windows):
1) Extract this ZIP
2) Double-click "start-server.bat"
3) Your browser will open to http://localhost:3000

Notes:
- Requires Node.js (npm) installed.
- Health endpoint: http://localhost:3000/api/health
